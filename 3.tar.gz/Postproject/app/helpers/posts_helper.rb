module PostsHelper

end
